#!/bin/bash

docker rm -f linotp &>/dev/null

echo "Creando contenedor 'linotp'" 
docker run -itd -p 80:80 --name linotp \
           -e LIN_USER=AMX \
           -e LIN_REALM=AMX \
           -e LIN_PASS=1234 \
           -e DB_HOST=172.17.0.2 \
           -e DB_USER=root \
           -e DB_PASS=mypass \
           -e DB_NAME=AMX-LINOTP \
	   -v /etc/localtime:/etc/localtime:ro \
           linotp:latest 
